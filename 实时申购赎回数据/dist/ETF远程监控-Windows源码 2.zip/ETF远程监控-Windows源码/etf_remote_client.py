#!/usr/bin/env python3
"""Cross-platform PyQt6 client for the ETF monitor server."""

from __future__ import annotations

import json
import sys
from datetime import datetime
from typing import Any

from PyQt6.QtCore import QSettings, Qt, QTimer, QUrl
from PyQt6.QtGui import QColor, QFont
from PyQt6.QtNetwork import (
    QAbstractSocket,
    QNetworkAccessManager,
    QNetworkReply,
    QNetworkRequest,
)
from PyQt6.QtWebSockets import QWebSocket
from PyQt6.QtWidgets import (
    QApplication,
    QCheckBox,
    QDialog,
    QFrame,
    QGridLayout,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QLineEdit,
    QMainWindow,
    QMessageBox,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
    QTabWidget,
    QVBoxLayout,
    QWidget,
)


class ClientAlertPopup(QDialog):
    def __init__(self, message: str) -> None:
        super().__init__(None)
        self.setWindowTitle("数据变化提醒")
        self.setWindowFlags(
            Qt.WindowType.Dialog
            | Qt.WindowType.WindowStaysOnTopHint
            | Qt.WindowType.Tool
        )
        self.resize(540, 230)
        layout = QVBoxLayout(self)
        heading = QLabel("检测到申购赎回份额变化")
        heading.setStyleSheet("font-size: 18px; font-weight: 700; color: #172033;")
        content = QLabel(message)
        content.setWordWrap(True)
        close_button = QPushButton("知道了")
        close_button.clicked.connect(self.close)
        layout.addWidget(heading)
        layout.addWidget(content, 1)
        layout.addWidget(close_button, 0, Qt.AlignmentFlag.AlignRight)
        self.setStyleSheet(
            "QDialog { background: white; } QLabel { color: #253044; }"
            "QPushButton { color: white; background: #2f6feb; border: 0; "
            "border-radius: 6px; padding: 8px 18px; }"
        )


class PcfDetailDialog(QDialog):
    def __init__(self, payload: dict[str, Any], parent: QWidget | None = None) -> None:
        super().__init__(parent)
        symbol = str(payload.get("symbol") or "")
        self.setWindowTitle(f"{symbol} PCF 详细信息")
        self.resize(1120, 720)
        layout = QVBoxLayout(self)

        heading = QLabel(
            f"{symbol}  {payload.get('fund_name') or ''}  ·  PCF {payload.get('trading_day') or '—'}"
        )
        heading.setStyleSheet("font-size: 18px; font-weight: 700; color: #172033;")
        opportunity = payload.get("opportunity") or {}
        signal = QLabel(
            f"判断：{opportunity.get('label') or '待确认'}  ·  {opportunity.get('reason') or ''}"
        )
        signal.setWordWrap(True)
        kind = str(opportunity.get("kind") or "")
        signal.setStyleSheet(
            "font-weight: 600; color: "
            + ("#168553;" if kind == "creation" else "#c53b45;" if kind == "redemption" else "#68758a;")
        )
        layout.addWidget(heading)
        layout.addWidget(signal)

        tabs = QTabWidget()
        summary = payload.get("summary_fields") or []
        summary_table = QTableWidget(len(summary), 2)
        summary_table.setHorizontalHeaderLabels(["字段", "值"])
        summary_table.verticalHeader().setVisible(False)
        summary_table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        summary_table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.ResizeToContents)
        summary_table.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)
        for row, field in enumerate(summary):
            summary_table.setItem(row, 0, QTableWidgetItem(str(field.get("label") or field.get("field") or "")))
            summary_table.setItem(row, 1, QTableWidgetItem(str(field.get("value") or "")))
        tabs.addTab(summary_table, "清单摘要")

        columns = payload.get("component_columns") or []
        components = payload.get("components") or []
        component_table = QTableWidget(len(components), len(columns))
        component_table.setHorizontalHeaderLabels(
            [str(column.get("label") or column.get("field") or "") for column in columns]
        )
        component_table.verticalHeader().setVisible(False)
        component_table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        component_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.ResizeToContents)
        for row, component in enumerate(components):
            for column, descriptor in enumerate(columns):
                field = str(descriptor.get("field") or "")
                component_table.setItem(row, column, QTableWidgetItem(str(component.get(field) or "")))
        tabs.addTab(component_table, f"成分证券（{len(components)}）")
        layout.addWidget(tabs, 1)

        if payload.get("error"):
            error = QLabel(f"提示：{payload['error']}")
            error.setWordWrap(True)
            error.setStyleSheet("color: #c53b45;")
            layout.addWidget(error)
        close_button = QPushButton("关闭")
        close_button.clicked.connect(self.close)
        layout.addWidget(close_button, 0, Qt.AlignmentFlag.AlignRight)


class RemoteClientWindow(QMainWindow):
    def __init__(
        self,
        *,
        settings_name: str = "ETFRemoteClient",
        window_title: str = "ETF 远程监控",
        default_address: str = "127.0.0.1:6787",
    ) -> None:
        super().__init__()
        self.settings = QSettings("ETFDelivery", settings_name)
        self.default_address = default_address
        self.socket = QWebSocket()
        self.network = QNetworkAccessManager(self)
        self.want_connection = False
        self.items: dict[str, dict[str, Any]] = {}
        self.alert_popups: list[ClientAlertPopup] = []
        self.pcf_dialogs: list[PcfDetailDialog] = []

        self.setWindowTitle(window_title)
        self.resize(1160, 680)
        self._build_ui()
        self._apply_style()
        self._restore_settings()

        self.socket.connected.connect(self._on_connected)
        self.socket.disconnected.connect(self._on_disconnected)
        self.socket.textMessageReceived.connect(self._on_text_message)
        self.socket.errorOccurred.connect(self._on_socket_error)
        self.reconnect_timer = QTimer(self)
        self.reconnect_timer.setInterval(5000)
        self.reconnect_timer.timeout.connect(self._try_reconnect)
        self.ping_timer = QTimer(self)
        self.ping_timer.setInterval(15000)
        self.ping_timer.timeout.connect(self._send_ping)

    def _build_ui(self) -> None:
        root = QWidget()
        root.setObjectName("appRoot")
        layout = QVBoxLayout(root)
        layout.setContentsMargins(22, 20, 22, 18)
        layout.setSpacing(14)
        self.root_layout = layout

        connection = QFrame()
        connection.setObjectName("card")
        self.connection_card = connection
        grid = QGridLayout(connection)
        grid.setContentsMargins(16, 14, 16, 14)
        grid.setHorizontalSpacing(10)
        grid.addWidget(QLabel("主机地址"), 0, 0)
        self.address_input = QLineEdit()
        self.address_input.setPlaceholderText("例如 192.168.1.20:6787")
        self.address_input.returnPressed.connect(self.connect_server)
        grid.addWidget(self.address_input, 0, 1)

        self.connect_button = QPushButton("连接")
        self.connect_button.setObjectName("primaryButton")
        self.connect_button.clicked.connect(self.connect_server)
        self.disconnect_button = QPushButton("断开")
        self.disconnect_button.clicked.connect(self.disconnect_server)
        self.disconnect_button.setEnabled(False)
        self.pull_button = QPushButton("拉取当前全量")
        self.pull_button.clicked.connect(self.pull_snapshot)
        self.pcf_refresh_button = QPushButton("刷新 PCF")
        self.pcf_refresh_button.clicked.connect(
            lambda: self._post("/api/v1/pcf/refresh")
        )
        self.remote_start_button = QPushButton("开始监控")
        self.remote_start_button.clicked.connect(
            lambda: self._post("/api/v1/monitor/start")
        )
        self.remote_stop_button = QPushButton("停止监控")
        self.remote_stop_button.clicked.connect(
            lambda: self._post("/api/v1/monitor/stop")
        )
        self.popup_check = QCheckBox("弹窗提醒")
        self.sound_check = QCheckBox("声音提醒")
        self.popup_check.setChecked(True)
        self.sound_check.setChecked(True)
        buttons = QHBoxLayout()
        for widget in (
            self.connect_button,
            self.disconnect_button,
            self.pull_button,
            self.pcf_refresh_button,
            self.remote_start_button,
            self.remote_stop_button,
            self.popup_check,
            self.sound_check,
        ):
            buttons.addWidget(widget)
        buttons.addStretch()
        grid.addLayout(buttons, 1, 0, 1, 2)
        layout.addWidget(connection)

        watchlist = QFrame()
        watchlist.setObjectName("card")
        watch_layout = QHBoxLayout(watchlist)
        watch_layout.setContentsMargins(16, 10, 16, 10)
        self.watchlist_label = QLabel("观察列表")
        watch_layout.addWidget(self.watchlist_label)
        self.symbol_input = QLineEdit()
        self.symbol_input.setPlaceholderText("6 位深圳代码")
        self.symbol_input.setMaximumWidth(180)
        self.add_symbol_button = QPushButton("添加")
        self.add_symbol_button.clicked.connect(self.add_remote_symbol)
        self.remove_symbol_button = QPushButton("删除选中")
        self.remove_symbol_button.clicked.connect(self.remove_remote_selected)
        watch_layout.addWidget(self.symbol_input)
        watch_layout.addWidget(self.add_symbol_button)
        watch_layout.addWidget(self.remove_symbol_button)
        watch_layout.addStretch()
        self.connection_label = QLabel("● 未连接")
        watch_layout.addWidget(self.connection_label)
        layout.addWidget(watchlist)

        self.table = QTableWidget(0, 11)
        self.table.setObjectName("monitorTable")
        self.table.setHorizontalHeaderLabels(
            [
                "标的",
                "主机状态",
                "申购笔数",
                "申购份额",
                "赎回笔数",
                "赎回份额",
                "轧差份额",
                "机会判断",
                "PCF 日期 / 最小单位",
                "更新时间",
                "最近变化",
            ]
        )
        self.table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.table.setSelectionMode(QTableWidget.SelectionMode.ExtendedSelection)
        self.table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.table.cellDoubleClicked.connect(self._open_pcf_for_row)
        self.table.verticalHeader().setVisible(False)
        header = self.table.horizontalHeader()
        header.setSectionResizeMode(QHeaderView.ResizeMode.ResizeToContents)
        header.setSectionResizeMode(10, QHeaderView.ResizeMode.Stretch)
        layout.addWidget(self.table, 1)

        self.footer_label = QLabel("WebSocket 等待连接")
        self.footer_label.setObjectName("detail")
        layout.addWidget(self.footer_label)
        self.setCentralWidget(root)

    def _apply_style(self) -> None:
        self.setStyleSheet(
            """
            QMainWindow, QWidget#appRoot { background: #f5f7fa; color: #1f2937; }
            QLabel, QCheckBox { background: transparent; color: #253044; }
            QCheckBox::indicator { width: 15px; height: 15px; background: white;
                                    border: 1px solid #aab7c7; border-radius: 3px; }
            QCheckBox::indicator:checked { background: #2f6feb; border-color: #2f6feb; }
            QFrame#card { background: white; border: 1px solid #dce3ec;
                          border-radius: 10px; }
            QLineEdit { color: #172033; background: white; border: 1px solid #cbd5e1;
                        border-radius: 6px; padding: 7px; min-height: 20px; }
            QPushButton { color: #283548; background: #f8fafc; border: 1px solid #cbd5e1;
                          border-radius: 6px; padding: 8px 14px; }
            QPushButton:hover { background: #eef3f9; }
            QPushButton:disabled { color: #9aa5b4; background: #f1f4f8; }
            QPushButton#primaryButton { color: white; background: #2f6feb;
                                        border-color: #2f6feb; }
            QTableWidget#monitorTable { color: #172033; background: white;
                          border: 1px solid #dce3ec; border-radius: 10px;
                          gridline-color: #e2e8f0; font-size: 13px; }
            QTableWidget#monitorTable::item { background: white; padding: 6px; }
            QTableWidget#monitorTable::item:selected { background: #dce9ff; color: #172033; }
            QHeaderView::section { background: #eef2f7; color: #526074; border: none;
                          border-right: 1px solid #dce3ec; border-bottom: 1px solid #dce3ec;
                          padding: 8px; font-weight: 600; }
            QLabel#detail { color: #68758a; }
            """
        )

    def _restore_settings(self) -> None:
        self.address_input.setText(
            str(self.settings.value("address", self.default_address))
        )
        self.popup_check.setChecked(
            str(self.settings.value("popup", "true")).lower() == "true"
        )
        self.sound_check.setChecked(
            str(self.settings.value("sound", "true")).lower() == "true"
        )

    def _save_settings(self) -> None:
        self.settings.setValue("address", self.address_input.text().strip())
        self.settings.setValue("popup", self.popup_check.isChecked())
        self.settings.setValue("sound", self.sound_check.isChecked())

    def _host_port(self) -> str:
        value = self.address_input.text().strip()
        for prefix in ("http://", "https://", "ws://", "wss://"):
            if value.startswith(prefix):
                value = value[len(prefix) :]
        return value.rstrip("/")

    def connect_server(self) -> None:
        host = self._host_port()
        if not host:
            QMessageBox.warning(self, "连接信息不完整", "请输入主机地址。")
            return
        self._save_settings()
        self.want_connection = True
        self.connection_label.setText("● 正在连接…")
        if self.socket.state() != QAbstractSocket.SocketState.UnconnectedState:
            self.socket.abort()
        url = QUrl(f"ws://{host}/ws/v1/changes")
        self.socket.open(url)

    def disconnect_server(self) -> None:
        self.want_connection = False
        self.reconnect_timer.stop()
        self.ping_timer.stop()
        self.socket.close()

    def _try_reconnect(self) -> None:
        if (
            self.want_connection
            and self.socket.state() == QAbstractSocket.SocketState.UnconnectedState
        ):
            self.connect_server()

    def _on_connected(self) -> None:
        self.connection_label.setText("● 已连接")
        self.connection_label.setStyleSheet("color: #168553;")
        self.connect_button.setEnabled(False)
        self.disconnect_button.setEnabled(True)
        self.reconnect_timer.stop()
        self.ping_timer.start()
        self.footer_label.setText("WebSocket 已连接，等待主机推送")
        self.pull_snapshot()

    def _on_disconnected(self) -> None:
        self.connection_label.setText("● 已断开")
        self.connection_label.setStyleSheet("color: #c53b45;")
        self.connect_button.setEnabled(True)
        self.disconnect_button.setEnabled(False)
        self.ping_timer.stop()
        if self.want_connection:
            self.reconnect_timer.start()

    def _send_ping(self) -> None:
        if self.socket.state() == QAbstractSocket.SocketState.ConnectedState:
            self.socket.sendTextMessage(json.dumps({"type": "ping"}))

    def _on_socket_error(self, _error: Any) -> None:
        self.footer_label.setText(f"连接错误：{self.socket.errorString()}")

    def _on_text_message(self, text: str) -> None:
        try:
            event = json.loads(text)
        except json.JSONDecodeError:
            return
        event_type = event.get("type")
        if event_type == "snapshot":
            self._apply_snapshot(event)
        elif event_type == "change":
            self._apply_change(event)
        elif event_type == "status":
            self.footer_label.setText(str(event.get("message", "")))
        elif event_type == "heartbeat":
            self.footer_label.setText(f"心跳 {event.get('server_time', '')}")
        elif event_type == "pong":
            self.footer_label.setText(f"连接正常 · {event.get('server_time', '')}")

    def _apply_snapshot(self, event: dict[str, Any]) -> None:
        self.items = {
            str(item.get("symbol")): item for item in event.get("items", [])
        }
        self._rebuild_table()
        state = "监控中" if event.get("monitoring") else "未监控"
        error = str(event.get("last_error") or "")
        self.footer_label.setText(
            error
            or f"全量已更新 · {len(self.items)} 个标的 · 主机{state} · {event.get('server_time', '')}"
        )

    def _apply_change(self, event: dict[str, Any]) -> None:
        messages: list[str] = []
        for changed in event.get("items", []):
            symbol = str(changed.get("symbol", ""))
            current = changed.get("current")
            if isinstance(current, dict):
                self.items[symbol] = current
            details = [str(item.get("text", "")) for item in changed.get("changes", [])]
            if isinstance(current, dict):
                opportunity = current.get("opportunity") or {}
                if opportunity.get("label"):
                    details.append(f"机会判断 {opportunity['label']}")
            messages.append(f"{symbol}：{'；'.join(details)}")
        self._rebuild_table()
        if not messages:
            return
        combined = "\n".join(messages)
        self.footer_label.setText(f"收到变化推送 · {event.get('server_time', '')}")
        if self.sound_check.isChecked():
            QApplication.beep()
        if self.popup_check.isChecked():
            popup = ClientAlertPopup(combined)
            self.alert_popups.append(popup)
            popup.finished.connect(lambda _result, item=popup: self._remove_popup(item))
            popup.show()
            QTimer.singleShot(12000, popup.close)

    def _remove_popup(self, popup: ClientAlertPopup) -> None:
        if popup in self.alert_popups:
            self.alert_popups.remove(popup)

    @staticmethod
    def _format(value: Any, signed: bool = False) -> str:
        if not isinstance(value, (int, float)):
            return "—"
        if signed and value > 0:
            return f"+{value:,.0f}"
        return f"{value:,.0f}"

    @staticmethod
    def _status_text(value: Any) -> str:
        return {
            "waiting": "等待数据",
            "connecting": "连接中",
            "monitoring": "监控中",
            "cached": "缓存数据",
            "stopped": "已停止",
            "error": "错误",
            "reconnecting": "重连中",
        }.get(str(value), str(value or "—"))

    def _rebuild_table(self) -> None:
        symbols = sorted(self.items)
        self.table.setRowCount(len(symbols))
        for row, symbol in enumerate(symbols):
            item = self.items[symbol]
            values = item.get("values", {})
            changes = item.get("last_change", [])
            pcf = item.get("pcf") or {}
            opportunity = item.get("opportunity") or {}
            pcf_unit = pcf.get("creation_redemption_unit")
            pcf_text = (
                f"{pcf.get('trading_day')} / {self._format(pcf_unit)}"
                if pcf.get("trading_day") and isinstance(pcf_unit, (int, float))
                else "拉取中" if pcf.get("status") == "waiting" else "—"
            )
            row_values = [
                symbol,
                self._status_text(item.get("status")),
                self._format(values.get("etfbuynumber")),
                self._format(values.get("etfbuyamount")),
                self._format(values.get("etfsellnumber")),
                self._format(values.get("etfsellamount")),
                self._format(values.get("netamount"), signed=True),
                opportunity.get("label") or "待确认",
                pcf_text,
                item.get("updated_at") or "—",
                "；".join(str(change.get("text", "")) for change in changes) or "—",
            ]
            for column, value in enumerate(row_values):
                cell = QTableWidgetItem(str(value))
                cell.setTextAlignment(
                    Qt.AlignmentFlag.AlignHCenter | Qt.AlignmentFlag.AlignVCenter
                )
                if column == 6 and isinstance(values.get("netamount"), (int, float)):
                    net = values["netamount"]
                    cell.setForeground(QColor("#168553" if net > 0 else "#c53b45" if net < 0 else "#526074"))
                if column == 7:
                    kind = str(opportunity.get("kind") or "")
                    cell.setForeground(
                        QColor("#168553" if kind == "creation" else "#c53b45" if kind == "redemption" else "#68758a")
                    )
                self.table.setItem(row, column, cell)

    def _request(
        self,
        method: str,
        path: str,
        body: dict[str, Any] | None = None,
        *,
        request_kind: str = "",
    ) -> None:
        host = self._host_port()
        if not host:
            return
        request = QNetworkRequest(QUrl(f"http://{host}{path}"))
        request.setHeader(QNetworkRequest.KnownHeaders.ContentTypeHeader, "application/json")
        payload = json.dumps(body or {}, ensure_ascii=False).encode("utf-8")
        if method == "GET":
            reply = self.network.get(request)
        elif method == "PUT":
            reply = self.network.put(request, payload)
        else:
            reply = self.network.post(request, payload)
        reply.setProperty("request_kind", request_kind)
        reply.finished.connect(lambda item=reply: self._http_finished(item))

    def _http_finished(self, reply: QNetworkReply) -> None:
        request_kind = str(reply.property("request_kind") or "")
        data = bytes(reply.readAll())
        status = reply.attribute(QNetworkRequest.Attribute.HttpStatusCodeAttribute)
        reply.deleteLater()
        try:
            payload = json.loads(data) if data else {}
        except json.JSONDecodeError:
            payload = {}
        if status is None or int(status) >= 400:
            self.footer_label.setText(
                f"请求失败 HTTP {status}: {payload.get('detail', data.decode(errors='replace'))}"
            )
            return
        if request_kind == "pcf-detail":
            self._show_pcf_detail(payload)
            return
        if payload.get("type") == "snapshot":
            self._apply_snapshot(payload)
        elif "symbols" in payload:
            self.pull_snapshot()

    def pull_snapshot(self) -> None:
        if self.socket.state() == QAbstractSocket.SocketState.ConnectedState:
            self.socket.sendTextMessage(json.dumps({"type": "get_snapshot"}))
        else:
            self._request("GET", "/api/v1/snapshot")

    def _post(self, path: str) -> None:
        self._request("POST", path)

    def _open_pcf_for_row(self, row: int, _column: int) -> None:
        symbol_cell = self.table.item(row, 0)
        if symbol_cell is None:
            return
        symbol = symbol_cell.text().strip()
        self.footer_label.setText(f"正在读取 {symbol} 的当日 PCF…")
        self._request(
            "GET", f"/api/v1/pcf/{symbol}", request_kind="pcf-detail"
        )

    def _show_pcf_detail(self, payload: dict[str, Any]) -> None:
        dialog = PcfDetailDialog(payload, self)
        self.pcf_dialogs.append(dialog)
        dialog.finished.connect(
            lambda _result, item=dialog: self._remove_pcf_dialog(item)
        )
        dialog.show()
        dialog.raise_()
        self.footer_label.setText(
            f"PCF 已打开 · {payload.get('symbol', '')} · {payload.get('trading_day') or '无日期'}"
        )

    def _remove_pcf_dialog(self, dialog: PcfDetailDialog) -> None:
        if dialog in self.pcf_dialogs:
            self.pcf_dialogs.remove(dialog)

    def add_remote_symbol(self) -> None:
        code = self.symbol_input.text().strip()
        if len(code) != 6 or not code.isdigit():
            QMessageBox.warning(self, "代码错误", "请输入 6 位深圳代码。")
            return
        symbols = sorted(set(self.items) | {code})
        self._request("PUT", "/api/v1/watchlist", {"symbols": symbols})
        self.symbol_input.clear()

    def remove_remote_selected(self) -> None:
        selected = {index.row() for index in self.table.selectedIndexes()}
        remove = {
            self.table.item(row, 0).text() for row in selected if self.table.item(row, 0)
        }
        symbols = [symbol for symbol in sorted(self.items) if symbol not in remove]
        if not symbols:
            QMessageBox.warning(self, "不能删除", "观察列表至少保留一个标的。")
            return
        self._request("PUT", "/api/v1/watchlist", {"symbols": symbols})

    def closeEvent(self, event: Any) -> None:
        self.want_connection = False
        self._save_settings()
        self.ping_timer.stop()
        self.socket.close()
        event.accept()


def main() -> int:
    app = QApplication(sys.argv)
    app.setApplicationName("ETF 远程监控")
    app.setOrganizationName("ETFDelivery")
    font = QFont()
    font.setPointSize(13)
    app.setFont(font)
    window = RemoteClientWindow()
    window.show()
    QTimer.singleShot(0, window.connect_server)
    return app.exec()


if __name__ == "__main__":
    raise SystemExit(main())
