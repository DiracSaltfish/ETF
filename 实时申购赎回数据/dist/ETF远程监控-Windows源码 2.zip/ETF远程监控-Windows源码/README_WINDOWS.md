# Windows 远程客户端源码

Windows 设备只运行远程客户端，不需要 Wind、lldb 或探针。它通过内网连接 Mac-home 的 `6787` 端口，启动时自动连接上次保存的地址，并在断线后自动重连。收到份额变化时，弹窗和声音都在 Windows 本机触发。

客户端会同时显示 Mac-home 分发的 PCF 日期、最小申赎单位和“申购机会/赎回机会”判断。双击任一标的会从主机读取该标的的 PCF 摘要与成分证券明细；PCF 的网络拉取和日期缓存都发生在 Mac-home，Windows 不会直接访问交易所接口。

## 直接运行源码

将本目录中的以下 4 个文件复制到 Windows 的同一文件夹：

- `etf_remote_client.py`
- `requirements-windows-client.txt`
- `启动Windows客户端.bat`
- `打包Windows客户端.bat`

安装 Python 3.10 或更高版本后，双击 `启动Windows客户端.bat`。脚本会自动创建 `.venv` 并安装 PyQt6。界面内输入 Mac-home 的地址，例如 `192.168.1.23:6787`。

## 打包 EXE

双击 `打包Windows客户端.bat`。产物位于：

```text
dist\ETF远程监控\ETF远程监控.exe
```

这是 `onedir` 版本，启动快且更容易排查依赖；分发时复制整个 `dist\ETF远程监控` 文件夹。打包必须在 Windows 上执行，不能用 Mac 交叉生成 Windows EXE。

## 网络条件

- Windows 与 Mac-home 必须能互相访问内网 IP。
- Mac-home 的系统防火墙需允许 `ETF监控主机` 接收入站连接。
- 服务按需求不使用令牌或实名验证，因此不要把 `6787` 映射到公网。
